---
title: Hexo website
date: 2012-04-12 23:33:26
link: http://www.hexo.io/
categories:
- tranquilpeak
- features
thumbnailImagePosition: left
thumbnailImage: http://d1u9biwaxjngwg.cloudfront.net/hexo-website/peak-140.jpg
---
This is a link post. Clicking on the link should open [Hexo](http://www.hexo.io/) in a new tab or window.
<!-- more -->